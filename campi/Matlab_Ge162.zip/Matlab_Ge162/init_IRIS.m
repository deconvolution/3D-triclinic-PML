javaaddpath('./IRIS/IRIS-WS-2.0.15.jar');
path(path,'/home/dbowden/SacMat_Ge162/IRIS');   % CHANGE to your own
